<footer class="footer text-white">
    <!-- Start Footer Top -->
    <div class="footer-top">
        <div class="container">
            <div class="inner-content">

                    <div class="row text-white text-center">
                        <div role="button" class="col-md-3 col-sm-6 khas-moto-footer">
                            <i class="display-4 bi bi-arrow-repeat"></i> <h4>Easy Returns</h4>
                        </div>
                        <div role="button" class="col-md-3 col-sm-6 khas-moto-footer">
                            <i  class="display-4 bi bi-truck"></i> <h4>Fast Delivery</h4>
                        </div>
                        <div role="button" class="col-md-3 col-sm-6 khas-moto-footer">
                            <i  class="display-4 bi bi-shield-check"></i>  <h4>Scam Free</h4>
                        </div>
                         <div role="button" class="col-md-3 col-sm-6 khas-moto-footer">
                            <i  class="display-4 bi bi-headset"></i><h4>24/7 Support</h4>

                </div>
            </div>
        </div>
    </div>
    <!-- End Footer Top -->
    <!-- Start Footer Middle -->
    {{-- <div class="footer-middle">
        <div class="container">
            <div class="bottom-inner">
                <div class="row">
                    <div class="col-lg-3 col-md-6 col-12">
                        <!-- Single Widget -->
                        <div class="single-footer f-contact">
                            <h3>Get In Touch With Us</h3>
                            <p class="phone">Phone: +92 3099779706</p>
                            <ul>
                                <li><span>Monday-Sunday: </span> 9.00 am - 8.00 pm</li>
                                <li><span>Break: </span> 1.00 pm - 2.00 pm</li>

                            </ul>
                            <p class="mail">
                                <a href="mailto:support@shopgrids.com">support@khas.com</a>
                            </p>
                        </div>
                        <!-- End Single Widget -->
                    </div>
                    <div class="col-lg-3 col-md-6 col-12">
                        <!-- Single Widget -->
                        <div class="single-footer our-app">
                            <h3>Our Mobile App</h3>

                        </div>
                        <!-- End Single Widget -->
                    </div>
                    <div class="col-lg-3 col-md-6 col-12">
                        <!-- Single Widget -->
                        <div class="single-footer f-link">
                            <h3>Information</h3>
                            <ul>
                                <li><a href="javascript:void(0)">About Us</a></li>
                                <li><a href="javascript:void(0)">Contact Us</a></li>
                                <li><a href="javascript:void(0)">Terms and Conditions</a></li>
                                <li><a href="javascript:void(0)">Privacy Policy</a></li>
                                <li><a href="javascript:void(0)">FAQs</a></li>
                            </ul>
                        </div>
                        <!-- End Single Widget -->
                    </div>
                    <div class="col-lg-3 col-md-6 col-12">
                        <!-- Single Widget -->
                        <div class="single-footer f-link">
                            <h3>Shop Now</h3>
                            <ul>
                                <li><a href="javascript:void(0)">Smartphones</a></li>
                                <li><a href="javascript:void(0)">Tablets</a></li>
                                <li><a href="javascript:void(0)">Gaming Phones</a></li>
                                <li><a href="javascript:void(0)">Cameras Phones</a></li>
                                <li><a href="javascript:void(0)">Accessories</a></li>
                            </ul>
                        </div>
                        <!-- End Single Widget -->
                    </div>
                </div>
            </div>
        </div>
    </div> --}}
    <!-- End Footer Middle -->
    <!-- Start Footer Bottom -->
    <div class="footer-bottom">
        <div class="container">
            <div class="inner-content">
                <div class="row align-items-center">
                    <div class="col-lg-4 col-12">
                        <div class="payment-gateway text-white">
                            <span>We Accept:</span>
                            <i class="bi bi-credit-card"></i>
                        </div>
                    </div>
                    <div class="col-lg-4 col-12">
                        <div class="copyright ">
                            <p>All Rights Reserved by<a class="text-white" href="/" >Khas</a></p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-12">
                        <ul class="footer-social-icons text-white">
                            <li>
                                <span>Follow Us On:</span>
                            </li>
                            <li><a class="text-white" href="javascript:void(0)"><i class="bi bi-facebook"></i></a></li>
                            <li><a class="text-white" href="javascript:void(0)"><i class="bi bi-twitter"></i></a></li>
                            <li><a class="text-white" href="javascript:void(0)"><i class="bi bi-instagram"></i></a></li>
                            <li><a class="text-white" href="javascript:void(0)"><i class="bi bi-youtube"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Footer Bottom -->
</footer>
<?php session()->forget('global_status');
session()->forget('global_error');
session()->forget('error');
session()->forget('status');

?>