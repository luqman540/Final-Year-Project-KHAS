@extends('AdminViews.Layout.layout')
@section('title','Attendance Report')
@section('style')
<style>

</style>

@endsection

@section('content')
  
    
  <main id="main" class="main">


    <section class="section dashboard">
      <div class="row bg-white shadow rounded-3">
      
        
{{-- Add Content Here --}}

      </div>
    </section>

  </main>
@endsection

@section('script')

<script>

</script>
@endsection