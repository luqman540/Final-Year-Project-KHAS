
<?php $__env->startSection('title','Add Return'); ?>
<?php $__env->startSection('style'); ?>
<style>

</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <main id="main" class="main">
    <section class="section dashboard">
      <div class="row bg-white shadow rounded-3">
      <div class="col-md-10 m-auto">
            <div class="card-body  ">
               <h5 class="card-title w-100 text-center display-3">Add Return</h5>
               <!-- Add user -->
               <form method="post" action="<?php echo e(route('return.getphone')); ?>">
                  <?php echo csrf_field(); ?>
                  <div class="row  mb-3 ">
                     <div class="col-md-6 mx-auto">
                        <label for="inputText" class="col-sm-12 col-form-label">Phone ID</label>
                        <div class="col-sm-12">
                        <input type="number" value="" name="phone_id" class="form-control">
                        </div>
                     </div>

                  </div>

                  <div class="row mb-3">
                     <div class="col-sm-12 text-center">
                        <button type="submit" class="btn btn-khas-primary">Find</button>
                     </div>
                  </div>
               </form>


               <?php if(!empty($phone)): ?>

               <div class="col-12">
                  <h3 class="w-100 text-center">Seller Info</h3>
                  <table class="table table-striped table-hover">
                     <input type="hidden" name="phone_id" value="<?php echo e($phone->id); ?>" />
                     <tr>
                        <th scope="row">Name</th>
                        <td><?php echo $phone->user? $phone->user->first_name." ".$phone->user->last_name  : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
                     </tr>
                     <tr>
                        <th scope="row">Phone</th>
                        <td><?php echo $phone->user? $phone->user->phone  : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
                     </tr>
                     <tr>
                        <th scope="row">Email</th>
                        <td><?php echo $phone->user? $phone->user->email  : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
                    <input type="hidden" name="seller_email" value="<?php echo e($phone->user->email); ?>"/>
                     </tr>
                     <tr>
                        <th scope="row">CNIC Number</th>
                        <td><?php echo $phone->user? $phone->user->cnic  : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
                     </tr>
                     <tr>
                        <th scope="row">Address</th>
                        <td><?php echo $phone->user? $phone->user->address  : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
                     </tr>
                  </table>
                           </div>

                           <div class="col-12 mt-4">
                  <h3 class="w-100 text-center">Cutomer Information</h3>
                  <table class="table table-striped table-hover">
                     <tbody>
                        <tr>
                           <th scope="row">Purchased By</th>
                           <td><?php echo $purchaser? $purchaser->first_name." ". $purchaser->last_name  : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
                        </tr>
                        <tr>
                           <th scope="row">Purchaser Phone</th>
                           <td><?php echo $purchaser? $purchaser->phone  : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
                        </tr>
                        <tr>
                           <th scope="row">Purchaser Email</th>
                           <td><?php echo $purchaser? $purchaser->email  : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
                           <input type="hidden" name="customer_email" value="<?php echo e($purchaser->email); ?>"/>

                        </tr>
                        <tr>
                           <th scope="row">Purchased At</th>
                           <td><?php echo $phone->created_at? $phone->created_at : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
                        </tr>
                        <tr>
                           <th scope="row">Payment Status</th>

                           <td><?php echo $transaction? $transaction->status : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
                        </tr>
                        <tr>
                           <th scope="row">Payment Done At</th>

                           <td><?php echo $transaction? $transaction->created_at : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
                        </tr>
                        <tr>
                           <th scope="row">Payment Method</th>

                           <td><?php echo $transaction? $transaction->method : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
                        </tr>
                        <tr>
                           <th scope="row">Transaction ID</th>

                           <td><?php echo $transaction? $transaction->transaction_id : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
                        </tr>
                        <tr>
                           <th scope="row">Amount</th>

                           <td><?php echo $transaction? "RS ". number_format($transaction->amount) : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
                        </tr>
                     </tbody>
                  </table>
                  <form method="post" action="<?php echo e(route('return.save')); ?>">
                     <?php echo csrf_field(); ?>
                     <div class="row mb-3">
                        <input type="hidden" value="<?php echo e($phone->id); ?>" name="phone_id" />
                        <div class="col-sm-12 text-center">
                           <button type="submit" class="btn btn-khas-primary">Return Now</button>
                        </div>
                     </div>
                  </form>
               <?php endif; ?>
               <!-- End General Form Elements -->
            </div>
         </div>

      </div>
    </section>

  </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('AdminViews.Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\khas\resources\views/AdminViews/Returns/add_return.blade.php ENDPATH**/ ?>