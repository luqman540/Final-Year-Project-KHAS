<button class="filter-btn btn-khas-secondary"><i class="bi bi-filter"></i>Filter</button>
<aside class="col-md-3 result-filter">
    <div class="col-12  rounded shadow-lg p-3 bg-white">
        <div class="row ">
        <span class="close-filter text-end w-100"><i class="text-danger bi bi-x-circle-fill"></i></span>
        <div class="col-12 btn btn-secondery">
<h4><i class="bi bi-filter"></i> Filter</h4><button class="btn-sm btn btn-primary resetfilter">Reset Filter</button>
        </div>
        <div class="accordion m-0  p-0" id="accordionbrandExample">
          <div class="accordion-item border-0">
            <h2 class="accordion-header" id="price-headingOne">
              <button class="accordion-button px-2" type="button" data-bs-toggle="collapse" data-bs-target="#price-collapseOne" aria-expanded="true" aria-controls="price-collapseOne">
                Price
              </button>
            </h2>
            <div id="price-collapseOne" class="accordion-collapse collapse show" aria-labelledby="price-headingOne">
              <div class="accordion-body">
                <input type="number" class="form-control mb-2 price_filter" placeholder="Min" id="min-price">
                <input type="number" class="form-control price_filter" placeholder="Max" id="max-price">
              </div>
            </div>
          </div>
          <?php if(!empty($brands)): ?>
            <div class="accordion-item border-0">
              <h2 class="accordion-header" id="brand-headingOne">
                <button class="accordion-button  px-2" type="button" data-bs-toggle="collapse" data-bs-target="#brand-collapseOne" aria-expanded="true" aria-controls="brand-collapseOne">
                  Brand
                </button>
              </h2>
              <div id="brand-collapseOne" class="accordion-collapse collapse show" aria-labelledby="brand-headingOne">
                <div class="accordion-body pre-scrollable">

                  <div class="form-group form-check">
                    <input type="radio" name="brand" value="all" class="form-check-input category_filter" id="brand">
                    <label class="form-check-label" for="brand">All</label>
                 </div>
<?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                    <div class="form-group form-check">
                        <input type="radio" name="brand" value="<?php echo e($brand->id); ?>" class="form-check-input category_filter" id="brand">
                        <label class="form-check-label" for="brand"><?php echo e($brand->name); ?></label>
                     </div>

                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>
              </div>
            </div>
            <?php endif; ?>


              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if(empty($cat->parent_id)): ?>
              <div class="accordion-item border-0">
                <h2 class="accordion-header" id="ram-heading<?php echo e($cat->id); ?>">
                  <button class="accordion-button  px-2" type="button" data-bs-toggle="collapse" data-bs-target="#ram-collapse<?php echo e($cat->id); ?>" aria-expanded="true" aria-controls="ram-collapse<?php echo e($cat->id); ?>">
                    <?php echo e($cat->prefix." ".$cat->name." ".$cat->suffix); ?>

                  </button>
                </h2>
                <div id="ram-collapse<?php echo e($cat->id); ?>" class="accordion-collapse collapse show" aria-labelledby="ram-heading<?php echo e($cat->id); ?>">
                  <div class="accordion-body">
                    <div class="form-group form-check">
                      <input type="radio" checked name="<?php echo e($cat->column_name); ?>" value="all" class="form-check-input category_filter" id="cat<?php echo e($cat->id); ?>">
                      <label class="form-check-label" for="cat<?php echo e($cat->id); ?>">All</label>
                   </div>
<?php $__currentLoopData = $cat->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="form-group form-check">
                        <input type="radio" name="<?php echo e($cat->column_name); ?>" value="<?php echo e($sub->name); ?>" class="form-check-input category_filter" id="cat<?php echo e($sub->id); ?>">
                        <label class="form-check-label" for="cat<?php echo e($sub->id); ?>"><?php echo e($sub->prefix." ".$sub->name." ".$sub->suffix); ?></label>
                     </div>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                </div>
              </div>
              <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



          </div>
        </div>
    </div>
</aside><?php /**PATH C:\xampp\htdocs\khas\resources\views/UserViews/Layout/Includes/sidebar.blade.php ENDPATH**/ ?>