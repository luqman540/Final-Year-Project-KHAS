<?php $__env->startComponent('mail::message'); ?>

#Phone Inspection Report
Dear <?php echo e($user->first_name); ?>,

We regret to inform you that one of the phones purchased by you in your order no. <?php echo e($purchase->purchase_id); ?> has been rejected during our initial inspection.

<span class="text-success">Your payment has been refunded in your wallet.</span>

Purchase ID: <?php echo e($purchase->purchase_id); ?>

Product ID: <?php echo e($inspection->phone_id); ?>

Phone Model: <?php echo e($phone->model); ?>

Color: <?php echo e($phone->color); ?>

Inspected at: <?php echo e($inspection->created_at); ?>

Inspected By: <?php echo e($admin->name); ?>

#Rejection Reason
The following details of the phone were different from the information provided by the seller in the post:

<?php $__env->startComponent('mail::panel'); ?>

<ul>
    <?php
    $inspectionArray = json_decode($inspection, true);
    foreach ($inspectionArray as $key => $value) {
        if ($value === "true") {
            $formattedKey = str_replace('_', ' ', $key);
            echo '<li>' . $formattedKey . '</li>';
        }
    }
    ?>
</ul>
<?php echo $__env->renderComponent(); ?>


If you have any questions, please feel free to contact us.

Thank you for shopping with us!

<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH C:\xampp\htdocs\khas\resources\views/emails/phone_rejected.blade.php ENDPATH**/ ?>