
<?php $__env->startSection('title','Pending Returns'); ?>
<?php $__env->startSection('style'); ?>
<style>

</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


  <main id="main" class="main">

    <section class="section dashboard">
      <div class="row bg-white shadow rounded-3">


      <div class="card-body">
            <h5 class="card-title">Pending Returns</h5>

            <!-- Default Table -->
            <table class="table">
              <thead>
                <tr>

                  <th scope="col">Phone Id</th>
                  <th scope="col">Customer Name</th>
                  <th scope="col">Total Amount</th>
                  <th scope="col">Date</th>
                  <th scope="col">Status</th>
                  <th scope="col">Actions</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $returns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <th scope="row"><?php echo e($r->phone_id); ?></th>
                  <td><?php echo e($r->user->first_name." ".$r->user->last_name); ?></td>
                  <td><?php echo e("Rs ".number_format($r->phone->price)); ?></td>
                  <td><?php echo e($r->created_at->format('d,M,Y')); ?></td>
                  <td><?php echo e($r->status); ?></td>

                  <td> <a href="#" class="btn btn-success btn-sm"   data-bs-toggle="modal" data-bs-target="#returnModal<?php echo e($r->phone_id); ?>"><i class="bi bi-eye"></i></a>

</td>
                </tr>
                <div class="modal fade" id="returnModal<?php echo e($r->phone_id); ?>" tabindex="-1" aria-labelledby="returnModal<?php echo e($r->phone_id); ?>Label" aria-hidden="true">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="returnModal<?php echo e($r->phone_id); ?>Label">Return Request</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                          <div class="mb-3 w-100">
                            <b>Phone : </b><a href="<?php echo e(route('phones.show',$id=$r->phone_id)); ?>" target="_blank"><?php echo e($r->phone->title); ?></a>


                          </div>
                          <div class="mb-3 w-100">
                            <b for="reason" class="form-label">Reason for returning product:</b>
                            <p> <?php echo e($r->reason); ?></p>
                          </div>
                          <div class="mb-3 w-100">
                            <b for="message" class="form-label">Message:</b>
<?php echo e($r->message); ?>

                          </div>
                          <div class="d-flex justify-content-end ">
<?php if($r->return_file): ?>

                          <a type="button"  href="<?php echo e(url($r->return_file)); ?>" target="_blank" class="btn btn-primary mx-2">View File</a>
                    <?php endif; ?>
                    <form  class="mx-2"  method="POST" action="<?php echo e(route('return.update')); ?>">
                    <?php echo csrf_field(); ?>
<input type="hidden" value="<?php echo e($r->id); ?>" name="id">
<input type="hidden" value="Accepted" name="status">
<button type="submit" class="btn btn-success">Accept</button>
</form>
<form method="POST" class="mx-2" action="<?php echo e(route('return.update')); ?>">
  <?php echo csrf_field(); ?>
  <input type="hidden" value="<?php echo e($r->id); ?>" name="id">
  <input type="hidden" value="Rejected" name="status">
                          <button type="submit" class="btn btn-danger">Reject</button>
                    </form>
                  </div>
                      </div>
                    </div>
                  </div>
                </div>


                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </tbody>
            </table>
            <!-- End Default Table Example -->
          </div>

      </div>
    </section>

  </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('AdminViews.Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\khas\resources\views/AdminViews/Returns/pending_returns.blade.php ENDPATH**/ ?>