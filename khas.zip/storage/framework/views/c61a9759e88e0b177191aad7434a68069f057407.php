<span class="text-muted">Total <?php echo e($phones->total()); ?> Phones Found</span>

<?php $__currentLoopData = $phones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="row mb-3  p-4 shadow-lg bg-white rounded">
   <div class="col-md-3 mt-1"><img role="button" class="img-fluid img-responsive rounded product-image"
      src="<?php echo e($phone->main_image); ?>">
   </div>
   <div class="col-md-6 mt-1">
      <div class="d-flex align-items-center">
         <h3><a href="<?php echo e(route('phones.show',$id=$phone->id)); ?>"><?php echo e($phone->title); ?></a></h3>
         
      </div>
      <small class="text-muted font-italic "> <?php echo e(dateDiff($phone->created_at)); ?></small>
      
      <div class="mt-1 mb-1 spec-1">
         
         <span class="badge ms-1 rounded-pill text-muted border"><?php echo e($phone->get_brand->name); ?>

         </span>
         <span class="badge ms-1 rounded-pill text-muted border"><?php echo e($phone->model); ?>

         </span>
         <span class="badge ms-1 rounded-pill text-muted border"><?php echo e($phone->storage_capacity); ?>GB ROM</span>
         <span class="badge ms-1 rounded-pill text-muted border"><?php echo e($phone->ram); ?>GB RAM</span>
      </div>
      <p class="text-justify text-truncate para mb-0"><?php echo e($phone->description); ?><br><br>
      </p>
   </div>
   <div class="align-items-center align-content-center col-md-3 border-left mt-1">
      <div class="d-flex flex-row justify-content-center align-items-center">
         <h4 class="mr-1">RS <?php echo e($phone->formatted_price); ?>

         </h4>
         
      </div>
      <div class="d-flex flex-column mt-4">
         <a  href="<?php echo e(route('phones.show',$id=$phone->id)); ?>" class="btn btn-khas-primary btn-sm"
            type="button">Details</a>
         <?php if($phone->status==="Available"): ?>
         <button class="btn btn-outline-khas-primary btn-sm mt-2 add-to-favorites"
            data-phone-id="<?php echo e($phone->id); ?>"
            type="button">Add to favorites</button>
         <?php else: ?>
         <h4 class="text-danger m-auto mt-3">SOLD</h4>
         <?php endif; ?>
      </div>
   </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!-- Render pagination links -->
<?php echo e($phones->links('vendor.pagination.bootstrap-5')); ?><?php /**PATH C:\xampp\htdocs\khas\resources\views/UserViews/Home/phonelist.blade.php ENDPATH**/ ?>