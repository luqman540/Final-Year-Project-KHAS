
<?php $__env->startSection('title','Add Admin'); ?>
<?php $__env->startSection('style'); ?>
<style>

</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <main id="main" class="main">

    <section class="section dashboard">
      <div class="row bg-white shadow rounded-3">

      <div class="col-md-10 m-auto">
            <div class="card-body  ">
               <h5 class="card-title w-100 text-center display-3">Add Admin</h5>

               <?php if(!empty($admin)): ?>
               <form action="<?php echo e(route('admin.create',$id=$admin->id)); ?>" method="POST">
                  <?php else: ?>
                  <form action="<?php echo e(route('admin.create')); ?>" method="POST">
                  <?php endif; ?>
                  <?php echo csrf_field(); ?>
                  <div class="row mb-3">
                      <label for="inputName" class="col-sm-12 col-form-label">Name</label>
                      <div class="col-sm-12">
                          <input type="text" class="form-control" name="name" id="inputName" placeholder="Enter name" value="<?php echo e(!empty($admin)?$admin->name: old('name')); ?>">
                          <?php if($errors->has('name')): ?>
                              <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                          <?php endif; ?>
                      </div>
                  </div>
                  <div class="row mb-3">
                      <label for="inputEmail" class="col-sm-12 col-form-label">Email</label>
                      <div class="col-sm-12">
                          <input type="email" class="form-control" name="email" id="inputEmail" placeholder="Enter email" value="<?php echo e(!empty($admin)?$admin->email: old('email')); ?>">
                          <?php if($errors->has('email')): ?>
                              <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                          <?php endif; ?>
                      </div>
                  </div>
                  <div class="row mb-3">
                      <label for="inputPhone" class="col-sm-12 col-form-label">Phone</label>
                      <div class="col-sm-12">
                          <input type="text" class="form-control" name="phone" id="inputPhone" placeholder="Enter phone number" value="<?php echo e(!empty($admin)?$admin->phone: old('phone')); ?>">
                          <?php if($errors->has('phone')): ?>
                              <span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
                          <?php endif; ?>
                      </div>
                  </div>
                  <div class="row mb-3">
                      <label for="inputRole" class="col-sm-12 col-form-label">Role</label>
                      <div class="col-sm-12">
                          <select class="form-control" name="role" id="inputRole">

                           <?php $__empty_1 = true; $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                           <option value="<?php echo e($role->id); ?>" <?php echo e(((!empty($admin)) && ($admin->role == $role->id))?'selected':''); ?>  <?php echo e(old('role') == $role->id ? 'selected' : ''); ?>><?php echo e($role->role); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                           <?php endif; ?>

                          </select>
                          <?php if($errors->has('role')): ?>
                              <span class="text-danger"><?php echo e($errors->first('role')); ?></span>
                          <?php endif; ?>
                      </div>
                  </div>
                  <div class="row mb-3">
                      <div class="col-sm-12 text-center">
                          <button type="reset" class="btn btn-khas-primary mx-2">Reset</button>
                          <button type="submit" class="btn btn-khas-primary mx-2">Save</button>
                      </div>
                  </div>
              </form>


            </div>
         </div>
      </div>
    </section>

  </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminViews.Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\khas\resources\views/AdminViews/Roles/assign_roles.blade.php ENDPATH**/ ?>