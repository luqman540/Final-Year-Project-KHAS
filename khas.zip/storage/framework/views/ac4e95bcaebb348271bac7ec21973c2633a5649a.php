<?php $__env->startComponent('mail::message'); ?>
# Congratulations on Your Sale

Dear <?php echo e($seller->first_name." ".$seller->last_name); ?>,
We are happy to inform you that your phone has been sold! Here are the details of the sale:

<b>Please kindly bring your phone to our nearest office for an inspection within 48 Hours.<p>

- Purchase ID: <?php echo e($purchase->id); ?>

- Post ID: <?php echo e($phone->id); ?>

- Post Title: <?php echo e($phone->title); ?>

- Phone Brand: <?php echo e($phone->get_brand->name); ?>

- Phone Model: <?php echo e($phone->model); ?>

- Buyer Name: <?php echo e($purchase->recivers_name); ?>

- Buyer Email: <?php echo e($purchase->recivers_email); ?>

- Buyer Phone: <?php echo e($purchase->recivers_phone); ?>

- Phone Price: RS <?php echo e(number_format($phone->price, 2)); ?>


<p style="color:red">Please note that if you do not bring your phone to us within 48 hours, this order will be cancelled and your account may be penalized.</p>

If you have any questions or need assistance, please don't hesitate to contact us.

Thank you for using our platform to sell your phone!


<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\khas\resources\views/emails/order/newOrder.blade.php ENDPATH**/ ?>