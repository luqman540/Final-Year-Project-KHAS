
<?php $__env->startSection('title','Add Roles'); ?>
<?php $__env->startSection('style'); ?>
<style>
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<main id="main" class="main">
   <section class="section dashboard">
      <div class="row bg-white shadow rounded-3">
         <div class="panel-body">
            <form action="<?php echo e(route('role.create')); ?>" method="POST">
          <?php echo csrf_field(); ?>
                <div class="form-group row my-3">
               <label for="type" class="col-sm-3 col-form-label">Role Name <i class="text-danger">*</i></label>
               <div class="col-sm-6">
                  <input type="text" value="<?php echo e(!empty($role) ? $role->role : old('role')); ?>"
                  class="form-control" name="role" id="type" placeholder="Role Name" required="">
               </div>
            </div>

                <?php $__empty_1 = true; $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <h2 class=""><?php echo e($module->module_name); ?></h2>
                <table class="table">
                <thead>

                    <tr>
                        <th>Sl No</th>
                        <th>Menu Name</th>
                        <th>Create (<label for="checkAllcreate0"><input type="checkbox" onclick="checkallcreate(<?php echo e($module->id); ?>)" id="checkAllcreate<?php echo e($module->id); ?>" name=""> All)</label></th>
                        <th>Read (<input type="checkbox" onclick="checkallread(<?php echo e($module->id); ?>)" id="checkAllread<?php echo e($module->id); ?>" name=""> all)</th>
                        <th>Update (<input type="checkbox" onclick="checkalledit(<?php echo e($module->id); ?>)" id="checkAlledit<?php echo e($module->id); ?>" name=""> all)</th>
                        <th>Delete (<input type="checkbox" onclick="checkalldelete(<?php echo e($module->id); ?>)" id="checkAlldelete<?php echo e($module->id); ?>" name=""> all)</th>
                    </tr>
                </thead>
                <tbody >

                    <?php $__empty_2 = true; $__currentLoopData = $module->subModules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>

                    <tr>
                        <td><?php echo e($loop->index+1); ?></td>
                        <td>
                            <?php echo e($sub_module->module_name); ?>

                            
                            <input type="hidden" name="module_id[]" value="<?php echo e($module->id); ?>">
                        </td>

                        <td>
                            <div class="checkbox checkbox-success text-center">
                                <input type="checkbox" name="create[]" value="1" id="create00" class="createcheckbox<?php echo e($module->id); ?>"
                                
>
                                                                                        <label for="create00"></label>
                            </div>
                        </td>
                        <td>
                            <div class="checkbox checkbox-success text-center">
                            <input type="checkbox" name="read[]" value="1" id="read00" class="readcheckbox<?php echo e($module->id); ?>">
                            <label for="read00"></label>
                            </div>
                        </td>
                        <td>
                            <div class="checkbox checkbox-success text-center">
                            <input type="checkbox" name="update[]" value="1" id="update00" class="editcheckbox<?php echo e($module->id); ?>">
                            <label for="update00"></label>
                            </div>
                        </td>
                        <td>
                            <div class="checkbox checkbox-success text-center">
                            <input type="checkbox" name="delete[]" value="1" id="delete00" class="deletecheckbox<?php echo e($module->id); ?>">
                            <label for="delete00"></label>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>

                    <tr>
                        <td>1</td>
                        <td>
                        <?php echo e($module->module_name); ?>

                        <input type="hidden" name="module_id[]" value="<?php echo e($module->id); ?>">
                        <input type="hidden" name="sub_module_id[]" value="0">
                        </td>
                        <td>
                        <div class="checkbox checkbox-success text-center">
                            <input type="checkbox" name="create[]" value="1" id="create00" class="createcheckbox<?php echo e($module->id); ?>">
                            <label for="create00"></label>
                        </div>
                        </td>
                        <td>
                        <div class="checkbox checkbox-success text-center">
                            <input type="checkbox" name="read[]" value="1" id="read00" class="readcheckbox<?php echo e($module->id); ?>">
                            <label for="read00"></label>
                        </div>
                        </td>
                        <td>
                        <div class="checkbox checkbox-success text-center">
                            <input type="checkbox" name="update[]" value="1" id="update00" class="editcheckbox<?php echo e($module->id); ?>">
                            <label for="update00"></label>
                        </div>
                        </td>
                        <td>
                        <div class="checkbox checkbox-success text-center">
                            <input type="checkbox" name="delete[]" value="1" id="delete00" class="deletecheckbox<?php echo e($module->id); ?>">
                            <label for="delete00"></label>
                        </div>
                        </td>
                    </tr>

                    <?php endif; ?>
                </tbody>

                </table>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <table class="table">
    <tr><td class="text-disabled text-center">No Data Found</td></tr>
    </table>

    <?php endif; ?>
            <div class="form-group text-right">
               <button type="reset" class="btn btn-danger w-md m-b-5">Reset</button>
               <button type="submit" class="btn  btn-primary w-md m-b-5">Save</button>
            </div>
         </div>
        </form>
      </div>
   </section>
</main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>

function checkallcreate(Id) {
    $('.createcheckbox'+Id).prop('checked', function(i, val) {
    return !val;
  });
}
function checkallread(Id) {
    $('.readcheckbox'+Id).prop('checked', function(i, val) {
    return !val;
  });
}
function checkalledit(Id) {
    $('.editcheckbox'+Id).prop('checked', function(i, val) {
    return !val;
  });
}
function checkalldelete(Id) {
    $('.deletecheckbox'+Id).prop('checked', function(i, val) {
    return !val;
  });
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminViews.Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\khas\resources\views/AdminViews/Roles/add_role.blade.php ENDPATH**/ ?>