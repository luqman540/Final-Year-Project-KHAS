
<?php $__env->startSection('title','Add Brand'); ?>
<?php $__env->startSection('style'); ?>
<style>
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<main id="main" class="main">
   <section class="section dashboard">
      <div class="row bg-white shadow rounded-3">
       <div class="container">
         <h1>Add New Brand</h1>
         <?php if($brand): ?>

            <form action="<?php echo e(route('brand.update', $brand->id)); ?>" method="POST">
               <?php echo method_field('PUT'); ?>

            <?php else: ?>
            <form action="<?php echo e(route('brand.create')); ?>" method="POST">


         <?php endif; ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" class="form-control" name="name" id="name" value="<?php echo e($brand?$brand->name:old('name')); ?>" required>
               </div>
               <div class="d-flex">

                   <button type="submit" class="btn mx-auto my-4 btn-primary">Save Changes</button>
                </div>
           </form>
       </div>
      </div>
   </section>
</main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('AdminViews.Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\khas\resources\views/AdminViews/Product/manage_brands/add_brand.blade.php ENDPATH**/ ?>