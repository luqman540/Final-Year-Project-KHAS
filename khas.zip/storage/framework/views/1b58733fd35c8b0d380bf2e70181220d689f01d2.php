
<?php $__env->startSection('title','Roles List'); ?>
<?php $__env->startSection('style'); ?>
<style>

</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


  <main id="main" class="main">


    <section class="section dashboard">
      <div class="row bg-white shadow rounded-3">

      <div class="card-body">
            <h5 class="card-title">Roles List</h5>

            <!-- Default Table -->
            <div class="table-responsive">
              <table id="moduless-table" class="datatable table table-striped responsive">

              <thead>
                  <tr>
                      <th scope="col">#</th>

                      <th scope="col">Role</th>
                      <th scope="col">Created On</th>
                      <th scope="col">Created By</th>
                      <th scope="col">Actions</th>
                  </tr>
              </thead>
              <tbody>
                  <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                      <th scope="row"><?php echo e($role->id); ?></th>
                      <td><?php echo e($role->role); ?></td>
                      <td><?php echo e(\Carbon\Carbon::parse($role->created_at)->format('Y,m,d')); ?></td>
                      <td><?php echo e($role->admin_name); ?></td>
                      <td>
                          <a href="<?php echo e(route('role.add',$id=$role->id)); ?>" class="btn btn-primary btn-sm"><i class="bi bi-pencil-square"></i></a>
                          <a href="#" class="btn btn-danger btn-sm delete-role" data-id="<?php echo e($role->id); ?>"><i class="bi bi-trash-fill"></i></a>
                      </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
          </table>

            <!-- End Default Table Example -->
          </div>

      </div>
      </div>
    </section>

  </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
 $(document).ready(function() {
        $('.datatable').DataTable({
          "pageLength": 20
        });
      });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('AdminViews.Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\khas\resources\views/AdminViews/Roles/roles_list.blade.php ENDPATH**/ ?>