
<?php $__env->startSection('title','Check Out'); ?>
<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/purchase/checkout.css')); ?>">
<script src="https://js.stripe.com/v3/"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="checkout-wrapper section col-12 pt-4 pb-4 ">
   <div class="container">
      <?php if($errors->any()): ?>
      <div class="alert alert-danger">
          <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
      </div>
  <?php endif; ?>
      <form action="<?php echo e(route('pay.now')); ?>" class="needs-validation" novalidate method="post" id="payment-form">
      <div class="row justify-content-center ">
         <div class="col-lg-8">
            <div class="checkout-steps-form-style-1 bg-white p-4 pt-1 rounded border ">
                  <div class="row">
                     <div class="col-md-12">
                        <div class="single-form form-default">
                           <h3>Shipping Information</h3>
                           <div class="row">
                              <div class="col-md-6 form-input form">
                                 <label>Recivers Name</label>
                                 <input type="text" name="recivers_name" value=<?php echo e($authUser->first_name." ".$authUser->last_name); ?> placeholder="Recivers Name">
                              </div>
                              <div class="col-md-6 form-input form">
                                 <label>Recivers Phone</label>
                                 <input type="text" name="recivers_phone" value="<?php echo e($authUser->phone); ?>" placeholder="Recivers Phone">
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-md-6">
                        <div class="single-form form-default">
                           <label>Email Address</label>
                           <div class="form-input form">
                              <input type="text" name="recivers_email" value="<?php echo e($authUser->email); ?>" placeholder="Email Address">
                           </div>
                        </div>
                     </div>
                     <div class="col-md-6">
                        <div class="single-form form-default">
                           <label>City</label>
                           <div class="form-input form">
                              <input type="text" name="recivers_city" value="<?php echo e($authUser->default_address?$authUser->city:""); ?>" placeholder="City">
                           </div>
                        </div>
                     </div>
                     <div class="col-md-12">
                        <div class="single-form form-default">
                           <label>Full Address</label>
                           <div class="form-input form">
                              <input type="text" name="recivers_address" value="<?php echo e($authUser->default_address?$authUser->address:""); ?>" placeholder="Full Address">
                           </div>
                        </div>
                     </div>
                     <div class="col-md-6">
                        <div class="single-form form-default">
                           <label>Zip Code</label>
                           <div class="form-input form">
                              <input type="text" name="recivers_zip_code" value="<?php echo e($authUser->default_address?$authUser->zip_code:""); ?>"  placeholder="Zip Code">
                           </div>
                        </div>
                     </div>
                     
                  </div>
                  <div class="row mt-1">
                     <div class="col-12">
                     </div>
                  </div>

            </div>
         </div>
         <div class="col-lg-4">
            <div class="checkout-sidebar">
               
               <div class="checkout-sidebar-price-table mt-30">
                  <h5 class="title">Pricing Table</h5>
                  <div class="sub-total-price">
                     <div class="total-price">
                        <p class="value">Total Items:</p>
                        <p class="price"><?php echo e(count($items)); ?></p>
                     </div>
                     <div class="total-price">
                        <p class="value">Subotal Price:</p>
                        <p class="price">RS/<?php echo e($totalPrice); ?></p>
                     </div>
                     
                  </div>
                  <div class="total-payable">
                     <div class="payable-price">
                        <p class="value">Total Price:</p>
                        <p class="price">RS/<?php echo e($totalPrice); ?></p>
                        <input type="hidden" name="totalPrice" value="<?php echo e($totalPrice); ?>">

                     </div>
                  </div>
               </div>
               <div class="bg-white border p-3 mt-4">
                  <h5 class="title">Payment Method</h5>                  <div class="payment-method-selection col-12 d-flex justify-content-around my-3 flex-wrap">
                   <div>
                     <input type="radio" id="card-option"  name="payment_method" value="card" checked>
                     <label for="card-option">Card</label>
                   </div>
                   <div>
                     <input type="radio" id="wallet-option"  name="payment_method" value="wallet">
                     <label for="wallet-option">Wallet</label>
                  </div>
                  </div>

                  <div class="checkout-payment-form">
                     
                     <div id="card-payment-form">
                        <?php echo csrf_field(); ?>
                        <div class="form-row">
                           <div class="col-md-12 mb-3">
                              <label for="card-element">Card Information</label>
                              <div id="card-element" class="form-control"></div>
                              <div id="card-errors" role="alert" class="invalid-feedback"></div>
                           </div>
                        </div>
                        <button class="btn btn-primary w-100" id="paybycard" type="submit">Pay Now (<?php echo e($totalPrice); ?>)</button>
                     </div>

                     
                     <div id="wallet-payment-form" style="display: none;">
                        <!-- Add your wallet payment form fields here -->
                        <?php if(intval($totalPrice) <= intval($authUser->balance)): ?>
                        <p class="my-2">Your Current Balance is Rs <?php echo e($authUser->balance); ?></p>
                        <button class="btn btn-primary w-100" type="submit">Pay Now (<?php echo e($totalPrice); ?>)</button>
                        <?php else: ?>
                        <p class="my-2 text-danger">Insufficent Balance.Your Current Balance is Rs <?php echo e($authUser->balance); ?>.Please change payment method or deposite balance in your wallet.</p>

                        <?php endif; ?>
                     </div>
                  </div>
               </div>


            </div>
         </div>
      </div>
   </form>
   </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
      $('input[type="radio"]').on('change', function() {
         var selectedPaymentMethod = $(this).val();

         if (selectedPaymentMethod === "card") {
            $('#card-payment-form').show();
            $('#wallet-payment-form').hide();
         } else if (selectedPaymentMethod === "wallet") {
            $('#card-payment-form').hide();
            $('#wallet-payment-form').show();
         }
      });
   });
   // Create a Stripe client.
   var stripe = Stripe('<?php echo e(env("STRIPE_KEY")); ?>');
   const elements = stripe.elements();
   // Custom styling can be passed to options when creating an Element.

   const style = {
   base: {
   fontSize: '16px',
   fontSmoothing: 'antialiased',
   color: '#495057',
   '::placeholder': {
     color: '#6c757d',
   },
   lineHeight: '1.5',
   },
   invalid: {
   color: '#dc3545',
   iconColor: '#dc3545',
   },
   };


   // Create an instance of the card Element.
   const card = elements.create('card', {style});

   // Add an instance of the card Element into the `card-element` <div>.
   card.mount('#card-element');

   // Create a token or display an error when the form is submitted.
   const form = document.getElementById('payment-form');
   const submitBtn = document.getElementById('paybycard');
   submitBtn.addEventListener('click', async (event) => {
   event.preventDefault();

   const {token, error} = await stripe.createToken(card);

   if (error) {
   // Inform the customer that there was an error.
   const errorElement = document.getElementById('card-errors');
   errorElement.textContent = error.message;
   } else {
   // Send the token to your server.
   stripeTokenHandler(token);
   }
   });

   const stripeTokenHandler = (token) => {
   // Insert the token ID into the form so it gets submitted to the server
   const form = document.getElementById('payment-form');
   const hiddenInput = document.createElement('input');
   hiddenInput.setAttribute('type', 'hidden');
   hiddenInput.setAttribute('name', 'stripeToken');
   hiddenInput.setAttribute('value', token.id);
   form.appendChild(hiddenInput);

   // Submit the form
   form.submit();
   }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('UserViews/Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\khas\resources\views/UserViews/Purchase/checkout.blade.php ENDPATH**/ ?>