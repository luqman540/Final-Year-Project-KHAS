


  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

       <li class="nav-item">
        <a class="nav-link " href="<?php echo e(route('dashboard.view')); ?>">
          <i class="bi bi-grid"></i>
          <span>Dashboard</span>
        </a>
      </li>

       <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#users" data-bs-toggle="collapse" href="#">
          <i class="bi bi-people-fill"></i><span>Users</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="users" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="<?php echo e(route('users.add')); ?>">
              <i class="bi bi-person-plus-fill"></i><span>Add User</span>
            </a>
          </li>
          <li>
            <a href="<?php echo e(route('users.list')); ?>">
              <i class="bi bi-person-lines-fill"></i><span>User List</span>
            </a>
          </li>

       <li>
            <a href="<?php echo e(route('users.report')); ?>">
              <i class="bi bi-pie-chart-fill"></i><span>Report</span>
            </a>
          </li>


        </ul>
      </li>

      <!-- End Components Nav -->



      
      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#products" data-bs-toggle="collapse" href="#">
          <i class="bi bi-box-seam-fill"></i><span>Products</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="products" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="<?php echo e(url('admin/products_list')); ?>">
              <i class="bi bi-list-task"></i><span>Products List</span>
            </a>
          </li>
          <li>
            <a href="<?php echo e(url('admin/removed_products_list')); ?>">
              <i class="bi bi-trash2-fill"></i><span>Removed Products</span>
            </a>
          </li>
          <li>



            <li class="nav-item sub-menu-dropdown" id="category-parent">
              <a class="nav-link collapsed" data-bs-target="#category" data-bs-toggle="collapse" href="#">
                <i class="bi bi-tag-fill"></i><span>Categories</span><i class="bi bi-chevron-down ms-auto"></i>
              </a>
              <ul id="category" class="nav-content collapse" data-bs-parent="#category-parent">

                <li>
                  <a href="<?php echo e(url('admin/add_category')); ?>">
                    <i class="bi bi-file-plus-fill"></i><span>Add Category</span>
                  </a>
                </li>
                <li>
                  <a href="<?php echo e(url('admin/category_list')); ?>">
                    <i class="bi bi-list-task"></i><span>Category List</span>
                  </a>
                </li>

              </ul>
            </li>
            <li class="nav-item sub-menu-dropdown" id="brands-parent">
              <a class="nav-link collapsed" data-bs-target="#brands" data-bs-toggle="collapse" href="#">
                <i class="bi bi-shop-window"></i><span>Brands</span><i class="bi bi-chevron-down ms-auto"></i>
              </a>
              <ul id="brands" class="nav-content collapse" data-bs-parent="#brands-parent">

                <li>
                  <a href="<?php echo e(url('admin/add_brands')); ?>">
                    <i class="bi bi-bag-plus-fill"></i><span>Add Brands</span>
                  </a>
                </li>
                <li>
                  <a href="<?php echo e(url('admin/brands_list')); ?>">
                    <i class="bi bi-list-task"></i><span>Brands List</span>
                  </a>
                </li>

              </ul>
            </li>
            <li class="nav-item sub-menu-dropdown" id="inspection-parent">
              <a class="nav-link collapsed" data-bs-target="#inspection" data-bs-toggle="collapse" href="#">
                <i class="bi bi-shop-window"></i><span>Inspection</span><i class="bi bi-chevron-down ms-auto"></i>
              </a>
              <ul id="inspection" class="nav-content collapse" data-bs-parent="#inspection-parent">

                <li>
                  <a href="<?php echo e(route('admin.inspection.add')); ?>">
                    <i class="bi bi-shield-check"></i><span>Add inspection</span>
                  </a>
                </li>
                <li>
                  <a href="<?php echo e(route('admin.inspection.list')); ?>">
                    <i class="bi bi-shield-fill-check"></i><span>Inspection Report</span>
                  </a>
                </li>

              </ul>
            </li>

          

        </ul>
      </li><!-- End Products Nav -->


<li class="nav-item" id="sales-parent">
  <a class="nav-link collapsed" data-bs-target="#sales" data-bs-toggle="collapse" href="#">
    <i class="bi bi-cart-fill"></i><span>Sales</span><i class="bi bi-chevron-down ms-auto"></i>
  </a>
  <ul id="sales" class="nav-content collapse" data-bs-parent="#sales-parent">

    <li>
      <a href="<?php echo e(url('admin/pending_sales')); ?>">
        <i class="bi bi-cart"></i><span>Pending Sales</span>
      </a>
    </li>
    <li>
      <a href="<?php echo e(url('admin/failed_sales')); ?>">
        <i class="bi bi-cart-x-fill"></i><span>Returned Sales</span>
      </a>
    </li>
    <li>
      <a href="<?php echo e(url('admin/completed_sales')); ?>">
        <i class="bi bi-cart-check-fill"></i><span>Completed Sales</span>
      </a>
    </li>
    

  </ul>
</li>





<li class="nav-item" id="finanace-parent">
  <a class="nav-link collapsed" data-bs-target="#finanace" data-bs-toggle="collapse" href="#">
    <i class="bi bi-bank2"></i><span>Finance</span><i class="bi bi-chevron-down ms-auto"></i>
  </a>
  <ul id="finanace" class="nav-content collapse" data-bs-parent="#finanace-parent">

    <li>
      <a href="<?php echo e(url('admin/txn_ledger')); ?>">
        <i class="bi bi-file-earmark-ruled-fill"></i><span>TXN Ledger</span>
      </a>
    </li>
    
    
    <li>
      <a href="<?php echo e(route('withdraw.requests')); ?>">
        <i class="bi bi-arrow-left-square-fill"></i><span>Withdraw Requests</span>
      </a>
    </li>
    <li>
      <a href="<?php echo e(url('admin/withdraw_history')); ?>">
        <i class="bi bi-clock-history"></i><span>Withdraw History</span>
      </a>
    </li>

    

  </ul>
</li>
















<li class="nav-item" id="returns-parent">
  <a class="nav-link collapsed" data-bs-target="#returns" data-bs-toggle="collapse" href="#">
    <i class="bi bi-arrow-repeat"></i><span>Returns</span><i class="bi bi-chevron-down ms-auto"></i>
  </a>
  <ul id="returns" class="nav-content collapse" data-bs-parent="#returns-parent">
    <li>
      <a href="<?php echo e(url('admin/add_return')); ?>">
        <i class="bi bi-reply-all-fill"></i><span>Add Return</span>
      </a>
    </li>
    <li>
      <a href="<?php echo e(url('admin/failed_sales')); ?>">
        <i class="bi bi-hourglass-bottom"></i><span>Pending Return</span>
      </a>
    </li>
    <li>
      <a href="<?php echo e(url('admin/completed_returns')); ?>">
        <i class="bi bi-check-square-fill"></i><span>Completed Return</span>
      </a>
    </li>
    

  </ul>
</li>





<li class="nav-item" id="roles-parent">
  <a class="nav-link collapsed" data-bs-target="#roles" data-bs-toggle="collapse" href="#">
    <i class="bi bi-award-fill"></i><span>Roles</span><i class="bi bi-chevron-down ms-auto"></i>
  </a>
  <ul id="roles" class="nav-content collapse" data-bs-parent="#roles-parent">
    <li>
      <a href="<?php echo e(route('role.add')); ?>">
        <i class="bi bi-node-plus-fill"></i><span>Add Role</span>
      </a>
    </li>
    <li>
      <a href="<?php echo e(route('role.list')); ?>">
        <i class="bi bi-person-lines-fill"></i><span>Roles List</span>
      </a>
    </li>
    <li>
      <a href="<?php echo e(route('admin.add')); ?>">
        <i class="bi bi-person-plus-fill"></i><span>Assign Roles</span>
      </a>
    </li>

  </ul>
</li>








    </ul>

  </aside><!-- End Sidebar-->
<?php /**PATH C:\xampp\htdocs\khas\resources\views/AdminViews/Layout/sidebar.blade.php ENDPATH**/ ?>