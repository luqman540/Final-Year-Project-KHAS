
<?php $__env->startSection('title',$user->first_name.' '.$user->last_name.' - Profile'); ?>
<?php $__env->startSection('style'); ?>
<style>
   .profile-pic{
   position: absolute;
   inset: 0px;
   box-sizing:border-box;
   padding: 0px;
   border: none;
   margin: auto;
   display: block;
   width: 0px;
   height: 0px;
   width: 100%;
   height: 100%;
   object-fit: cover;
   }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="section pt-4 pb-4 ">
   <div class="container  rounded my-4 ">
      <div class="row">
         <aside class=" col-lg-3 py-4 col-md-4 bg-white shadow rounded-3">
            <div class="">
               <div class="d-flex  flex-wrap justify-content-center">
                  -
                  <div class="position-relative rounded-circle overflow-hidden mx-auto mx-md-0 mb-3" style="width: 120px; height: 120px;">
                     <img alt="Profile Image" light="0" src=<?php echo e($user->photo); ?> decoding="async" data-nimg="fill" sizes="100vw"  class="profile-pic">
                  </div>
                  <div class="w-100 text-center">
                     <h2 class="h4 text-center  mb-1"><?php echo e($user->first_name.' '.$user->last_name); ?><i style="font-size: 10px;" class="text-success bi bi-circle-fill"></i></h2>
                     <p class="text-center   mb-2 pb-1"><b> Joined On : </b><span class="text-muted"><?php echo e($user->created_at->format('F j, Y')); ?><span>
                     </p>
                  </div>
                  
               </div>
               
            </div>
         </aside>
         <div class="col-lg-9 col-md-8  ">
            <div class="col-12 ">
               <div class="d-flex  flex-md-row flex-column align-items-md-center justify-content-md-between mb-lg-4 mb-3 pb-md-1">
                  <!-- Nav tabs-->
                  <div class="mb-md-0 mb-4 pb-1" style="overflow-x: auto;">
                     <ul class="nav nav-tabs nav-fill flex-nowrap text-nowrap mb-0" role="tablist">
                        <li class="nav-item" role="presentation"><a class="nav-link active" href="#avilable" data-bs-toggle="tab" role="tab" aria-selected="true">Available</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="#sold" data-bs-toggle="tab" role="tab" aria-selected="false" tabindex="-1">Sold </a></li>
                        
                     </ul>
                  </div>
               </div>
               <!-- Tabs content-->
               <div class="tab-content">
                  <!-- avilable products grid-->
                  <div class="tab-pane fade active show" id="avilable" role="tabpanel">
                     <div class="row row-cols-md-3 row-cols-sm-2 row-cols-1 gy-sm-4 gy-3">
                        <!-- Product-->
                        <?php $__empty_1 = true; $__currentLoopData = $user->phones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php if($phone->status=="Available"): ?>
                        <div class="col mb-3 ">
                           <article class="card h-100 border-0 bg-white shadow rounded-3">
                              <div class="card-img-top position-relative overflow-hidden" style="max-height: 14em;">
                                 <a class="d-block" href="<?php echo e(route('phones.show',$id=$phone->id)); ?>"><img width="100%" height="100%" src="<?php echo e($phone->main_image); ?>" alt="<?php echo e($phone->title); ?>" /></a>
                                 <span class="btn btn-success btn-sm position-absolute shadow" style="top: 10px; right: 10px;"><?php echo e($phone->condition); ?></span>
                              </div>
                              <div class="card-body">
                                 <h3 class="product-title mb-2 fs-base"><a class="d-block text-truncate" href="<?php echo e(route('phones.show',$id=$phone->id)); ?>"><?php echo e($phone->title); ?></a></h3>
                                 <div class="d-flex align-items-center flex-wrap">
                                    <h4 class="w-100 text-center">RS <?php echo e($phone->formatted_price); ?></h4>
                                 </div>
                              </div>
                              <div class="card-footer">
                                 <div class="d-flex justify-content-between my-3">
                                    <button class="btn btn-outline-khas-secondery btn-sm add-to-favorites" data-phone-id=<?php echo e($phone->id); ?>><i class="bi bi-heart"></i>Add to Fav</button>
                                    <button class="btn btn-outline-khas-secondery btn-sm addToCart" data-phone-id=<?php echo e($phone->id); ?>><i class="bi bi-cart"></i>Add to Cart</button>
                                 </div>
                                 <a href="<?php echo e(route('phones.show',$id=$phone->id)); ?>"> <button class="btn btn-primary col-12 mb-3"><i class="bi bi-eye"></i> View Details</button></a>
                                 <button class="btn btn-primary col-12 checkoutBtn" data-phone-id=<?php echo e($phone->id); ?>><i class="bi bi-bag-check"></i> Buy Now</button>
                              </div>
                           </article>
                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <span class="w-100 text-center text-muted">No Phones available to show</span>
                        <?php endif; ?>
                     </div>
                  </div>
                  <!-- sold-->
                  <div class="tab-pane fade" id="sold" role="tabpanel">
                     <!-- sold grid-->
                     <div class="row ">
                        <?php $__empty_1 = true; $__currentLoopData = $user->phones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php if($phone->status=="Sold"): ?>
                        <div class="col mb-3 ">
                           <article class="card h-100 border-0 bg-white shadow rounded-3">
                              <div class="card-img-top position-relative overflow-hidden" style="max-height: 14em;">
                                 <a class="d-block" href="<?php echo e(route('phones.show',$id=$phone->id)); ?>"><img width="100%" height="100%" src="<?php echo e($phone->main_image); ?>" alt="<?php echo e($phone->title); ?>" /></a>
                                 <span class="btn btn-success btn-sm position-absolute shadow" style="top: 10px; right: 10px;"><?php echo e($phone->condition); ?></span>
                              </div>
                              <div class="card-body">
                                 <h3 class="product-title mb-2 fs-base"><a class="d-block text-truncate" href="<?php echo e(route('phones.show',$id=$phone->id)); ?>"><?php echo e($phone->title); ?></a></h3>
                                 <div class="d-flex align-items-center flex-wrap">
                                    <h4 class="w-100 text-center">RS <?php echo e($phone->formatted_price); ?></h4>
                                 </div>
                              </div>
                              <div class="card-footer">
                                 <div class="d-flex justify-content-between my-3">
                                    <button class="btn btn-outline-khas-secondery btn-sm add-to-favorites" data-phone-id=<?php echo e($phone->id); ?>><i class="bi bi-heart"></i>Add to Fav</button>
                                    <button class="btn btn-outline-khas-secondery btn-sm addToCart" data-phone-id=<?php echo e($phone->id); ?>><i class="bi bi-cart"></i>Add to Cart</button>
                                 </div>
                                 <a href="<?php echo e(route('phones.show',$id=$phone->id)); ?>"> <button class="btn btn-primary col-12 mb-3"><i class="bi bi-eye"></i> View Details</button></a>
                                 <button class="btn btn-primary col-12 checkoutBtn" data-phone-id=<?php echo e($phone->id); ?>><i class="bi bi-bag-check"></i> Buy Now</button>
                              </div>
                           </article>
                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <span class="w-100 text-center text-muted">No Phones available to show</span>
                        <?php endif; ?>
                     </div>
                  </div>
                  
               </div>
            </div>
         </div>
      </div>
   </div>
   </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('UserViews/Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\khas\resources\views/UserViews/Profile/profile.blade.php ENDPATH**/ ?>