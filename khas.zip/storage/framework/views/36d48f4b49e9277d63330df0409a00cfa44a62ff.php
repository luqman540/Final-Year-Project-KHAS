<?php $__env->startComponent('mail::message'); ?>
# Phone Return Application

Dear <?php echo e($return->user->first_name); ?>,

Congratulation,

We are happy to inform you that your product return application has been accepted.


Kindly bring the phone to our nearrest office.

<?php $__env->startComponent('mail::panel'); ?>

<?php echo $__env->renderComponent(); ?>



If you have any questions, please feel free to contact us.

Thank you for shopping with us!

<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\khas\resources\views/emails/return/accepted.blade.php ENDPATH**/ ?>