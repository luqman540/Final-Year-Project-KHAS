# Your  <?php echo e(config('app.name')); ?>  Account<br>

Dear <?php echo e($user['name']); ?>, <br>

Your user account has been successfully created. You can now log in using the following credentials:

<?php $__env->startComponent('mail::table'); ?>
| Email    | Password |
|:---------|:---------|
| <?php echo e($user['email']); ?> | <?php echo e($password); ?> |
<?php echo $__env->renderComponent(); ?>
<br>
For security reasons, we recommend that you change your password after logging in.

<?php $__env->startComponent('mail::button', ['url' => url('/login')]); ?>
Go to Login Page
<?php echo $__env->renderComponent(); ?>

If you have any questions, please feel free to contact us.

Best regards,

Your  <?php echo e(config('app.name')); ?> team
<?php /**PATH C:\xampp\htdocs\khas\resources\views/emails/new_user_account.blade.php ENDPATH**/ ?>