
<?php $__env->startSection('title','User Dashboard'); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="checkout-wrapper section col-12 pt-4 pb-4 ">
   <div class="container">
      <div class="row justify-content-center ">

         <div class="container pb-5 mb-2 mb-md-4">
            <div class="row">
              <!-- Sidebar-->
            <?php echo $__env->make('UserViews/Profile/Components/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <section class="col-lg-9   px-4 pb-4 mb-3">

                  <!-- Title-->
                  <div class="d-sm-flex flex-wrap justify-content-between bg-white shadow rounded-3 px-3 py-2 align-items-center border-bottom">
                    <h2 class="h3 py-2 me-2 text-center text-sm-start">User Dashboard</h2>

                  </div>

                  <div class="row mx-n2 p-1 mt-4">
                    <div class="col-sm-6 px-2 mb-4">
                      <div class="text-white bg-primary shadow rounded-3 h-100 rounded-3 p-4 text-center">
                        <h3>Total Products</h3>
                        <p class="h2 mb-2"><?php echo e(count($authUser->phones)); ?></p>
                      </div>
                    </div>
                    <div class="col-sm-6 px-2 mb-4">
                        <div class="text-white bg-primary  shadow rounded-3 h-100 rounded-3 p-4 text-center">
                          <h3>Sold</h3>
                          <p class="h2 mb-2"><?php
                            $i = 0;
                        ?>
                        <?php $__currentLoopData = $authUser->phones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($phone->status == "Sold"): ?>
                                <?php
                                    $i++;
                                ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($i); ?>

                        </p>
                        </div>
                      </div>

                  </div>

                  <div class="row mx-n2 p-1 mt-4">
                    <div class="col-sm-6 px-2 mb-4">
                        <div class="bg-primary text-white shadow rounded-3 h-100 rounded-3 p-4 text-center">
                          <h3>Total Sales</h3>
                          <p class="h2 mb-2"><?php
                            $i = 0;
                        ?>
                        <?php $__currentLoopData = $authUser->phones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($phone->status == "Sold"): ?>
                                <?php
                                    $i=$i+$phone->price;
                                ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        Rs <?php echo e(number_format($i)); ?></p>
                        </div>
                      </div>
                    <div class="col-sm-6 px-2 mb-4">
                      <div class="bg-primary text-white shadow rounded-3 h-100 rounded-3 p-4 text-center">
                        <h3>Total Purchase</h3>
                        <p class="h2 mb-2"><?php
                          $i = 0;
                      ?>
                      <?php $__currentLoopData = $authUser->purchasedPhones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($phone->status != "Returned"): ?>
                              <?php
                                  $i=$i+$phone->phone->price;
                              ?>
                          <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      Rs <?php echo e(number_format($i)); ?></p>
                      </div>
                    </div>
                  </div>


                  





              </section>

            </div>
          </div>

      </div>
   </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('UserViews/Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\khas\resources\views/UserViews/Dashboard/dashboard.blade.php ENDPATH**/ ?>