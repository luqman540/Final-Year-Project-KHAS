<?php $__env->startComponent('mail::message'); ?>
# Phone Inspection Report

Dear <?php echo e($user->first_name); ?>,

We regret to inform you that your phone has been rejected during our initial inspection.

- Purchase ID: <?php echo e($purchase->purchase_id); ?>

- Product ID: <?php echo e($inspection->phone_id); ?>

- Phone Model: <?php echo e($phone->model); ?>

- Color: <?php echo e($phone->color); ?>

- Inspected at: <?php echo e($inspection->created_at); ?>

- Inspected By: <?php echo e($admin->name); ?>


## Rejection Reason

The following details of the phone were different from the information provided in your post:

<?php $__env->startComponent('mail::panel'); ?>
<ul>
    <?php
    $inspectionArray = json_decode($inspection, true);
    foreach ($inspectionArray as $key => $value) {
        if ($value === "true") {
            $formattedKey = str_replace('_', ' ', $key);
            echo '<li>' . $formattedKey . '</li>';
        }
    }
    ?>
</ul>
<?php echo $__env->renderComponent(); ?>



<span class="text-danger">If you think this is done by a mistake you can contact us.Other wise your account will be banne if this happens again.</span>
If you have any questions, please feel free to contact us.

Thank you for shopping with us!

<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\khas\resources\views/emails/phone_rejected_seller.blade.php ENDPATH**/ ?>