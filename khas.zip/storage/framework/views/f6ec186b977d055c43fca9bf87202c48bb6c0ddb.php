<?php $__env->startComponent('mail::message'); ?>
# Khas - Email Verification

Hello <?php echo e($user->first_name); ?>,

Thank you for registering on our website. Please verify your email address by entering the verification code below:

<?php $__env->startComponent('mail::panel'); ?>
<?php echo e($verification_code); ?>

<?php echo $__env->renderComponent(); ?>

Alternatively, you can click the button below to verify your email address.

<?php $__env->startComponent('mail::button', ['url' => url('/verify_email?code='.$verification_code.'&token='.$email_token)]); ?>
Verify Email
<?php echo $__env->renderComponent(); ?>
This link will expire after 60 minutes.
<br>
If you did not request this verification, please ignore this email.

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\khas\resources\views/emails/email_verification.blade.php ENDPATH**/ ?>