<footer class="footer text-white">
    <!-- Start Footer Top -->
    <div class="footer-top">
        <div class="container">
            <div class="inner-content">

                    <div class="row text-white text-center">
                        <div role="button" class="col-md-3 col-sm-6 khas-moto-footer">
                            <i class="display-4 bi bi-arrow-repeat"></i> <h4>Easy Returns</h4>
                        </div>
                        <div role="button" class="col-md-3 col-sm-6 khas-moto-footer">
                            <i  class="display-4 bi bi-truck"></i> <h4>Fast Delivery</h4>
                        </div>
                        <div role="button" class="col-md-3 col-sm-6 khas-moto-footer">
                            <i  class="display-4 bi bi-shield-check"></i>  <h4>Scam Free</h4>
                        </div>
                         <div role="button" class="col-md-3 col-sm-6 khas-moto-footer">
                            <i  class="display-4 bi bi-headset"></i><h4>24/7 Support</h4>

                </div>
            </div>
        </div>
    </div>
    <!-- End Footer Top -->
    <!-- Start Footer Middle -->
    
    <!-- End Footer Middle -->
    <!-- Start Footer Bottom -->
    <div class="footer-bottom">
        <div class="container">
            <div class="inner-content">
                <div class="row align-items-center">
                    <div class="col-lg-4 col-12">
                        <div class="payment-gateway text-white">
                            <span>We Accept:</span>
                            <i class="bi bi-credit-card"></i>
                        </div>
                    </div>
                    <div class="col-lg-4 col-12">
                        <div class="copyright ">
                            <p>All Rights Reserved by<a class="text-white" href="/" >Khas</a></p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-12">
                        <ul class="footer-social-icons text-white">
                            <li>
                                <span>Follow Us On:</span>
                            </li>
                            <li><a class="text-white" href="javascript:void(0)"><i class="bi bi-facebook"></i></a></li>
                            <li><a class="text-white" href="javascript:void(0)"><i class="bi bi-twitter"></i></a></li>
                            <li><a class="text-white" href="javascript:void(0)"><i class="bi bi-instagram"></i></a></li>
                            <li><a class="text-white" href="javascript:void(0)"><i class="bi bi-youtube"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Footer Bottom -->
</footer>
<?php session()->forget('global_status');
session()->forget('global_error');
session()->forget('error');
session()->forget('status');

?><?php /**PATH C:\xampp\htdocs\khas\resources\views/UserViews/Layout/Includes/footer.blade.php ENDPATH**/ ?>