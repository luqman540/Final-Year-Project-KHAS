
<?php $__env->startSection('title','Txn Ledger'); ?>
<?php $__env->startSection('style'); ?>
<style>

</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


  <main id="main" class="main">


    <section class="section dashboard">
      <div class="row bg-white shadow rounded-3">


      <div class="card-body">
            <h5 class="card-title">TXN Ledger</h5>

            <!-- Default Table -->
            <table class="table datatable">
              <thead>
                <tr>
                  <th style="display: none;"></th>
                  <th scope="col">Txn ID</th>
                  <th scope="col">User</th>
                  <th scope="col">Amount</th>
                  <th scope="col">Type</th>
                  <th scope="col">Status</th>
                  <th scope="col">Method</th>
                  <th scope="col">Date</th>
                </tr>
              </thead>
              <tbody>
              <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <th style="display: none;"><?php echo e($transaction->transaction_id); ?></th>
                  <th scope="row"><?php echo e(substr($transaction->transaction_id, 0, 6)); ?></th>

                  <td><?php echo e($transaction->user->first_name." ".$transaction->user->last_name); ?></td>
                  <td>RS <?php echo e(number_format($transaction->amount)); ?></td>
                  <td><?php echo e($transaction->transaction_type); ?></td>
                  <td><?php echo e($transaction->status); ?></td>
                  <td><?php echo e($transaction->method); ?></td>
                  <td><?php echo e($transaction->created_at->format('d,M,Y:H:s')); ?></td>
                </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
            <!-- End Default Table Example -->
          </div>

      </div>
    </section>

  </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
  $(document).ready(function() {
         $('.datatable').DataTable({
           "pageLength": 10,
           responsive: true,
  dom: '<"text-center" B>lfrtip',
    buttons: [
        'copyHtml5',
        'csvHtml5',
        'excelHtml5',
        'pdfHtml5'
    ],
    language: {
        searchPlaceholder: "Search...",
        lengthMenu: "Show _MENU_ entries per page",
        zeroRecords: "No entries found",
        info: "Showing _START_ to _END_ of _TOTAL_ entries",
        infoEmpty: "Showing 0 to 0 of 0 entries",
        infoFiltered: "(filtered from _MAX_ total entries)"
    },

         });
       });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('AdminViews.Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\khas\resources\views/AdminViews/Finance/txn_ledger.blade.php ENDPATH**/ ?>